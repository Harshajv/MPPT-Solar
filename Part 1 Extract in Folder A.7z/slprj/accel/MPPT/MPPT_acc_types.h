#include "__cf_MPPT.h"
#ifndef RTW_HEADER_MPPT_acc_types_h_
#define RTW_HEADER_MPPT_acc_types_h_
#include "rtwtypes.h"
#include "multiword_types.h"
typedef struct b2vgh5tvgj_ b2vgh5tvgj ; typedef struct h2ev02slmc_ h2ev02slmc
;
#endif
