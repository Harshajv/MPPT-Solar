#include "__cf_MPPT.h"
#ifndef RTW_HEADER_MPPT_acc_h_
#define RTW_HEADER_MPPT_acc_h_
#include <stddef.h>
#ifndef MPPT_acc_COMMON_INCLUDES_
#define MPPT_acc_COMMON_INCLUDES_
#include <stdlib.h>
#define S_FUNCTION_NAME simulink_only_sfcn 
#define S_FUNCTION_LEVEL 2
#define RTW_GENERATED_S_FUNCTION
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "MPPT_acc_types.h"
#include "multiword_types.h"
#include "mwmathutil.h"
#include "rt_zcfcn.h"
#include "rt_defines.h"
#include "rt_nonfinite.h"
typedef struct { real_T mxl35noq1s ; } gb5oerlwuf ; typedef struct { int8_T
hveluddu1l ; char_T fqbfai2aom [ 7 ] ; } og0hizz4vj ; typedef struct { real_T
av4vuu0cdc ; } letwoolrbl ; typedef struct { ZCSigState kknmzilkod ; }
celktmhpcw ; typedef struct { real_T e1pv5wp5qg ; real_T c3qvsjfkto ; real_T
h35du5bloe ; real_T g05iswhzeu ; real_T c2wpbx1x3s ; real_T fsasmh5xry ;
real_T oyw0wlipie ; real_T bd1nxmpwrb ; real_T fhb45fr2wm ; real_T p54c5qdkmg
; real_T n43clse2y1 ; real_T foghiasjib ; real_T jkfkm013qk ; real_T
pzfbuu1pev ; real_T jnax5h1vbb ; real_T dqkpecqryq ; real_T mr2hlmmvfl ;
real_T p3jgusjoma ; real_T myuptltuws ; real_T nyot21dz0i ; real_T fgboggrv5x
; real_T p2tkrxum3w ; real_T jakzpwqypn ; real_T fxg3vo3amu ; real_T
dfmpdzfrcp ; real_T cln5nbqta4 ; real_T bhiokjmgyn ; real_T eumrejilkf ;
real_T jcxohutlsr ; real_T lunhii5ybe ; real_T apeak1jtf4 ; real_T fjhf1tz0bs
; real_T jcwt0yv0vm ; real_T a55jdwqqex ; real_T nqufnfzep0 ; real_T
ddk0nof02a ; real_T k44ur1xucu ; real_T hi3aevogxy ; real_T phzsrohids ;
real_T gsxftwndtq ; real_T psdjrqztc1 ; real_T dfxeabzqzi ; real_T nprc0q1y2n
; real_T mfdhjleaul ; real_T p1mdvtiwqx ; real_T p4iftmj5sf ; real_T
gkgjrdtvm3 ; real_T jeppek0vhx ; real_T at4ugyqrok ; real_T lld0jfq4re ;
real_T lxekkqvqtj ; real_T ou5ymefycw ; real_T mcdf4rn2zi ; real_T hgkkjcmw2j
; real_T pgmk1gpvva ; real_T ekcrp0skk4 ; real_T jaarnzh1fm ; real_T
cxivyykhgk ; real_T ocncc4q2rd ; real_T h2h5hp3sjp ; real_T hsph1edgek ;
real_T i40qou5qgm ; real_T dkyvshn1hh ; real_T irm4aysjpi ; real_T fufjlnmi2y
[ 5 ] ; real_T ekxofouchb [ 4 ] ; real_T lcycrwgnbw ; real_T mtoympr2w3 ;
real_T js50ema3sn ; real_T muoovd5nsf ; real_T gcwlwb44fp ; real_T kj5jig4pqn
; real_T bgrrustgtm ; real_T ojqpb45qu0 ; boolean_T jqhya1d5ch ; char_T
ldbd0vfr4b [ 7 ] ; gb5oerlwuf b5cva55wbq ; gb5oerlwuf kb3gnicghzk ; }
nfjekb3bsc ; typedef struct { real_T plf1kykuf1 [ 2 ] ; void * peybpsn2y2 [ 3
] ; void * bjabmcze2x [ 3 ] ; void * hl5xkr1tzc ; void * kz4yyg5gmq [ 5 ] ;
void * oodahd125t [ 22 ] ; int_T h1cj3uuwsy [ 4 ] ; int_T j5ge1bjeod ; int_T
e431m3wb3u ; int_T dkxrgnrszi [ 4 ] ; int_T ohvufnqp1b ; int_T bvdmclgqmy ;
int_T frey3gnxda [ 23 ] ; int_T nnrge00vnv ; char pt5iyakypr [ 12 ] ;
boolean_T oys4fitgnf ; char_T kzmyvvxbdk [ 3 ] ; og0hizz4vj b5cva55wbq ;
og0hizz4vj kb3gnicghzk ; } pdevxrjmms ; typedef struct { real_T msfvxacfgs ;
real_T niig3zyce1 ; real_T fgrkgkxz0g [ 2 ] ; real_T dgdqaosuyg [ 2 ] ;
real_T o0iyt112py [ 3 ] ; } oykvejcuzo ; typedef struct { real_T msfvxacfgs ;
real_T niig3zyce1 ; real_T fgrkgkxz0g [ 2 ] ; real_T dgdqaosuyg [ 2 ] ;
real_T o0iyt112py [ 3 ] ; } kpbn2bgvlc ; typedef struct { boolean_T
msfvxacfgs ; boolean_T niig3zyce1 ; boolean_T fgrkgkxz0g [ 2 ] ; boolean_T
dgdqaosuyg [ 2 ] ; boolean_T o0iyt112py [ 3 ] ; } hhmskgfjpk ; typedef struct
{ real_T msfvxacfgs ; real_T niig3zyce1 ; real_T fgrkgkxz0g [ 2 ] ; real_T
dgdqaosuyg [ 2 ] ; real_T o0iyt112py [ 3 ] ; } ogkl1n0lbg ; typedef struct {
real_T noumthhrbj ; real_T e4kagp0zcy ; real_T fpluy4m5ij ; real_T khgxnowcp0
; real_T defoir3ecu ; letwoolrbl b5cva55wbq ; letwoolrbl kb3gnicghzk ; real_T
bki4kzg4hn [ 3 ] ; } h41hxo23lw ; typedef struct { ZCSigState acnawevc0n ;
ZCSigState fuhp30doy5 ; ZCSigState kot5qnytj5 ; ZCSigState igmyk5tau1 ;
ZCSigState hejmg1gvbn ; celktmhpcw b5cva55wbq ; celktmhpcw kb3gnicghzk ;
ZCSigState marlwsovsw [ 3 ] ; } d52acnsdym ; typedef struct { const real_T
ouhs1snykz ; } czfmq05egt ;
#define d2mzadeviz(S) ((czfmq05egt *) _ssGetConstBlockIO(S))
struct b2vgh5tvgj_ { real_T P_0 ; } ; struct h2ev02slmc_ { real_T P_0 [ 2 ] ;
real_T P_1 [ 200 ] ; real_T P_2 [ 2 ] ; real_T P_3 [ 4 ] ; real_T P_4 [ 2 ] ;
real_T P_5 [ 3 ] ; real_T P_6 [ 2 ] ; real_T P_7 [ 660 ] ; real_T P_8 [ 2 ] ;
real_T P_9 [ 4 ] ; real_T P_10 [ 2 ] ; real_T P_11 [ 2 ] ; real_T P_12 [ 2 ]
; real_T P_13 [ 2 ] ; real_T P_14 [ 2 ] ; real_T P_15 [ 2 ] ; real_T P_16 [ 2
] ; real_T P_17 ; real_T P_18 [ 2 ] ; real_T P_19 ; real_T P_20 ; real_T P_21
; real_T P_22 ; real_T P_23 ; real_T P_24 ; real_T P_25 ; real_T P_26 ;
real_T P_27 ; real_T P_28 ; real_T P_29 ; real_T P_30 ; real_T P_31 ; real_T
P_32 ; real_T P_33 ; real_T P_34 ; real_T P_35 ; real_T P_36 ; real_T P_37 ;
real_T P_38 ; real_T P_39 ; real_T P_40 ; real_T P_41 ; real_T P_42 ; real_T
P_43 ; real_T P_44 ; real_T P_45 ; real_T P_46 ; real_T P_47 ; real_T P_48 [
3 ] ; real_T P_49 ; real_T P_50 ; real_T P_51 ; real_T P_52 ; real_T P_53 ;
real_T P_54 [ 3 ] ; real_T P_55 ; real_T P_56 ; real_T P_57 ; real_T P_58 ;
real_T P_59 ; real_T P_60 ; real_T P_61 ; real_T P_62 ; real_T P_63 ; real_T
P_64 ; real_T P_65 ; real_T P_66 ; real_T P_67 ; real_T P_68 ; real_T P_69 ;
real_T P_70 ; real_T P_71 ; real_T P_72 ; real_T P_73 ; real_T P_74 ;
b2vgh5tvgj b5cva55wbq ; b2vgh5tvgj kb3gnicghzk ; } ; extern h2ev02slmc
g1rwbwt2np ; extern const czfmq05egt mzeefuhszk ;
#endif
